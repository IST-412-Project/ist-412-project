/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp311;

import javafx.collections.*;
import java.io.*;
import java.util.*;

/**
 *
 * @author brittanychapin
 */
public class ReminderList {
    private ArrayList<Reminder> theReminderList;

    
    public ObservableList<Reminder> getReminderData() {
        ObservableList<Reminder> theListOfReminders;
        List<Reminder> reminderList = (List<Reminder>) theReminderList;
        theListOfReminders = FXCollections.observableList(reminderList);
        return theListOfReminders;
    }
    
}
