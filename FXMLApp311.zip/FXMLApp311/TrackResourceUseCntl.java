/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp311;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author brittanychapin
 */
public class TrackResourceUseCntl {
    @FXML private Stage stage;
    private static TrackResourceUseCntl theTrackResourceCntl;
    
    private TrackResourceUseCntl(Stage theExistingStage){
        stage = theExistingStage;
        this.setUpTrackResourceUseScene();
        stage.show();
    }
    
    public static TrackResourceUseCntl getTrackResourceUseCntl(Stage theStage){
        if(theTrackResourceCntl != null){
            return theTrackResourceCntl;
        }else{
            theTrackResourceCntl = new TrackResourceUseCntl(theStage);
            return theTrackResourceCntl;
        }
    }
    
    @FXML public void setUpTrackResourceUseScene(){
        Parent root;
        Scene scene;
        try{
            root = FXMLLoader.load(getClass().getResource("TrackResourceUseUI.fxml"));
            scene = new Scene(root);
            stage.setTitle("Track Resource Use");
            stage.setScene(scene);
            stage.show();
        }catch(IOException e){
            ;
        }
    }
    
    public void getNavigationCntl(Stage theStage) {
        NavigationCntl.getNavigationCntl(theStage).setUpNavigationScene();
    }
    
    public Stage getStage(){
        return stage;
    }
    
    public void addResourceRow(User newUser){
        PersistentDataCntl.getPersistentDataCntl().getPeristentDataCollection().getuserList().getUserData().add(newUser);
        PersistentDataCntl.getPersistentDataCntl().writeSerializedDataModel();
    }
    
    public void exit(){
        System.exit(0);
    }
}
