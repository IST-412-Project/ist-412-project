/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fxmlapp311;

import java.io.Serializable;

/**
 *
 * @author brittanychapin
 */
public class Resource implements Serializable{
    
    private String name;
    private String type;
    private String amount;
    
    public Resource(String resourceName, String resourceType, String resourceAmount) {
        name = resourceName;
        type = resourceType;
        amount = resourceAmount;
    }
    
    public void setName(String newName) {
        name = newName;
    }
    public String getName() {
        return name;
    }
    
    public void seyType(String newType) {
        type = newType;
    }
    public String getType() {
        return type;
    }
    
    public void setAmount(String newAmount) {
        amount = newAmount;
    }
    public String getAmount() {
        return amount;
    }
    
}
